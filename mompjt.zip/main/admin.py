# main/admin.py - 관리자 페이지가 필요 없습니다
# 사용자 관리는 accounts/admin.py에서 처리합니다